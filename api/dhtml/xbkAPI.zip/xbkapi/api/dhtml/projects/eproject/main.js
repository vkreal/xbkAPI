var sLOGO = "";
sLOGO += "<table class='myTitle' width='100%' border='0' cellspacing='0' cellpadding='5'><tr>";
sLOGO += "<td height='40'>&nbsp;Project Manager</td>";
sLOGO += "<td class='mySubTitle' align='right' valign='bottom'><img src='images/logo.gif'>&nbsp;</td>";
sLOGO += "</tr><tr><td class='mySubTitle' align='left' valign='bottom'><a href=''>My Projects</a>&nbsp;|&nbsp;<a href=''>Home</a>&nbsp;|&nbsp;<a href=''>Help</a>&nbsp;|&nbsp;<a href=''>Log Out</a>&nbsp;</td></tr>";
sLOGO += "</table>";


var MONTHS = "";
MONTHS += "<table width='100%' border='0' cellspacing='0' cellpadding='5'><tr>";
MONTHS += "<td class='monthStyle' align='left'>&nbsp;October 2001</td>";
MONTHS += "<td class='monthStyle' align='left'>&nbsp;November 2001</td>";
MONTHS += "</tr></table>";


var DATES = "";
DATES += "<table width='100%' border='0' cellspacing='0' cellpadding='0'><tr>";
DATES += "<td class='dateStyle' align='left'>&nbsp;10/8</td>";
DATES += "<td class='dateStyle' align='left'>&nbsp;10/15</td>";
DATES += "<td class='dateStyle' align='left'>&nbsp;10/22</td>";
DATES += "<td class='dateStyle' align='left'>&nbsp;10/28</td>";
DATES += "<td class='dateStyle' align='left'>&nbsp;11/8</td>";
DATES += "<td class='dateStyle' align='left'>&nbsp;11/15</td>";
DATES += "<td class='dateStyle' align='left'>&nbsp;11/22</td>";
DATES += "<td class='dateStyle' align='left'>&nbsp;11/28</td>";
DATES += "</tr></table>";