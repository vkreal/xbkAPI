// @notFinished

/**
 *  SPC
 *	xbExample
 *	
 *	Class Description goes here 
 *
 *	@author		authorName		email
 *	@example	exampleTitle		pathToExampleFile	exampleComment
 *	@since		1.0
  *	@extends	extendsName
 *	@constructor	constructorClassName
 *	@param	name	Type		Description
 *
 */
 function xbLayer() {
 }

/**
 *	MethodName
 *	METHOD_Description
 *
 *	@public
 *	@param sname	string	paramComment
 *	@return boolean
 *
 */
xbLayer.prototype.MethodName = function(sname) {
}